// Селектор получает значение Счетчика
export const getCountValue = (state) => {
  return state.count.count;
};
